-- MySQL dump 10.13  Distrib 5.5.58, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: ssh_management
-- ------------------------------------------------------
-- Server version	5.5.58-0+deb8u1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `ssh_users`
--

DROP TABLE IF EXISTS `ssh_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ssh_users` (
  `username` varchar(50) NOT NULL,
  PRIMARY KEY (`username`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `link_server_groups`
--

DROP TABLE IF EXISTS `link_server_groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `link_server_groups` (
  `groupname` varchar(50) NOT NULL,
  `ssh_user_username` varchar(50) NOT NULL,
  `server_user` varchar(25) NOT NULL,
  `valid_from` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `valid_until` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`groupname`,`ssh_user_username`,`server_user`),
  UNIQUE KEY `server_hostname` (`groupname`,`ssh_user_username`,`server_user`),
  KEY `ssh_user_username` (`ssh_user_username`),
  KEY `server_user` (`server_user`),
  CONSTRAINT `link_server_groups_ibfk_1` FOREIGN KEY (`groupname`) REFERENCES `server_groups` (`groupname`) ON DELETE NO ACTION ON UPDATE CASCADE,
  CONSTRAINT `link_server_groups_ibfk_2` FOREIGN KEY (`ssh_user_username`) REFERENCES `ssh_users` (`username`) ON DELETE NO ACTION ON UPDATE CASCADE,
  CONSTRAINT `link_server_groups_ibfk_3` FOREIGN KEY (`server_user`) REFERENCES `server_users` (`user`) ON DELETE NO ACTION ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `link_servers`
--

DROP TABLE IF EXISTS `link_servers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `link_servers` (
  `server_hostname` varchar(50) NOT NULL,
  `ssh_user_username` varchar(50) NOT NULL,
  `server_user` varchar(25) NOT NULL,
  `valid_from` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `valid_until` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`server_hostname`,`ssh_user_username`,`server_user`),
  UNIQUE KEY `server_hostname` (`server_hostname`,`ssh_user_username`,`server_user`),
  KEY `ssh_user_username` (`ssh_user_username`),
  KEY `server_user` (`server_user`),
  CONSTRAINT `ssh_user_username` FOREIGN KEY (`ssh_user_username`) REFERENCES `ssh_users` (`username`) ON DELETE NO ACTION ON UPDATE CASCADE,
  CONSTRAINT `link_servers_ibfk_1` FOREIGN KEY (`server_user`) REFERENCES `server_users` (`user`) ON DELETE NO ACTION,
  CONSTRAINT `server_hostname` FOREIGN KEY (`server_hostname`) REFERENCES `servers` (`hostname`) ON DELETE NO ACTION ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `server_groups`
--

DROP TABLE IF EXISTS `server_groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `server_groups` (
  `groupname` varchar(20) CHARACTER SET utf8 NOT NULL,
  UNIQUE KEY `groupname` (`groupname`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `server_users`
--

DROP TABLE IF EXISTS `server_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `server_users` (
  `user` varchar(25) NOT NULL,
  PRIMARY KEY (`user`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `servers`
--

DROP TABLE IF EXISTS `servers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `servers` (
  `hostname` varchar(50) NOT NULL,
  PRIMARY KEY (`hostname`),
  UNIQUE KEY `hostname` (`hostname`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `servers_groups_link`
--

DROP TABLE IF EXISTS `servers_groups_link`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `servers_groups_link` (
  `server_hostname` varchar(50) NOT NULL,
  `server_groupname` varchar(20) NOT NULL,
  UNIQUE KEY `server_hosname` (`server_hostname`,`server_groupname`),
  KEY `server_groupname` (`server_groupname`),
  CONSTRAINT `servers_groups_link_ibfk_3` FOREIGN KEY (`server_hostname`) REFERENCES `servers` (`hostname`) ON DELETE NO ACTION ON UPDATE CASCADE,
  CONSTRAINT `servers_groups_link_ibfk_2` FOREIGN KEY (`server_groupname`) REFERENCES `server_groups` (`groupname`) ON DELETE NO ACTION ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `ssh_keys`
--

DROP TABLE IF EXISTS `ssh_keys`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ssh_keys` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `ssh_user` varchar(50) NOT NULL,
  `public_key` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `users` (`ssh_user`),
  CONSTRAINT `ssh_keys_ibfk_1` FOREIGN KEY (`ssh_user`) REFERENCES `ssh_users` (`username`) ON DELETE NO ACTION ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=24 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping routines for database 'ssh_management'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2017-12-22 10:19:57
